var express = require("express");
var path = require('path')

var consign = require('consign');

var app = express();
var bodyParser = require('body-parser');

app.set("view engine", "ejs");
app.set("views", "./app/views");

app.use(express.static("app/" + '/public'));


app.use(bodyParser.urlencoded({extended:true}));

consign({cwd:"app"})
    .include("routes")
    .into(app);

module.exports = app;