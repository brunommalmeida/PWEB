module.exports = function (app) {



    app.get('/informacao/professores/detalhaprofessor', function (req, res) {



        var connection = app.config.dbConnection();

        var professorModel = app.models.professorModel;// variável que recupera a função exporta



        //executar a função

        // tem passar a conexao e o callback

        professorModel.getProfessor(connection, function (error, results) {

            res.render('informacao/professores/detalhaprofessor', { profs: results });

        });



    });

}